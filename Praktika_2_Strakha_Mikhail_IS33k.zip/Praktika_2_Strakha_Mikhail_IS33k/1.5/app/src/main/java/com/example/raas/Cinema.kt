package com.example.raas

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView
import com.squareup.picasso.Picasso
import kotlin.text.toLong

class Cinema(context: Context, private val dataSource: Array<text>) : BaseAdapter() {
    private val inflater: LayoutInflater =
        context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater

    override fun getCount(): Int {
        return dataSource.size
    }

    override fun getItem(position: Int): Any {
        return dataSource[position]
    }

    override fun getItemId(position: Int): Long {
        return dataSource[position].new_tovar.toLong()
    }

    override fun getView(position: Int, convertView: View?, parent: ViewGroup): View {
        val row = inflater.inflate(R.layout.test, parent, false)

        val vnew_tovar: TextView = row.findViewById(R.id.textView1)
        val vname: TextView = row.findViewById(R.id.textView2)
        val vprice: TextView = row.findViewById(R.id.textView3)
        val vpieces: TextView = row.findViewById(R.id.textView4)
        val vdate: TextView = row.findViewById(R.id.textView5)
        val vphoto: ImageView = row.findViewById(R.id.imageView)

        val cinema = getItem(position) as text

        Picasso.get().load(cinema.photo).into(vphoto)
        vnew_tovar.text = "Код театра: ${cinema.new_tovar}"
        vname.text = "Название: ${cinema.name}"
        vprice.text = "Цена: ${cinema.price}"
        vpieces.text = "Мест: ${cinema.pieces}"
        vdate.text = "Дата: ${cinema.date}"

        return row
    }
}