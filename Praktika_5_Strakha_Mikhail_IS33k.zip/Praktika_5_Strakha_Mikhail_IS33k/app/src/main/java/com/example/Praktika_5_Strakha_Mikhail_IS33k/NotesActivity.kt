package com.example.Praktika_5_Strakha_Mikhail_IS33k

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.Praktika_5_Strakha_Mikhail_IS33k.databinding.ActivityNotesBinding
import java.text.SimpleDateFormat
import java.util.Date

class NotesActivity : AppCompatActivity() {

    lateinit var bindingNotesBinding: ActivityNotesBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        bindingNotesBinding = ActivityNotesBinding.inflate(layoutInflater)
        setContentView(bindingNotesBinding.root)

        val titleNote = bindingNotesBinding.editTextTextNoteTitle
        val textNote = bindingNotesBinding.editTextTextNoteText
        val createDate = bindingNotesBinding.textViewCreateTime

        val intent = intent
        if (intent.hasExtra("ID") && intent.hasExtra("TITLE") && intent.hasExtra("TEXT") && intent.hasExtra("DATE")) {
            val title = intent.getStringExtra("TITLE")
            val text = intent.getStringExtra("TEXT")
            val date = intent.getStringExtra("DATE")

            titleNote.setText(title)
            textNote.setText(text)
            createDate.setText(date)
        }

        bindingNotesBinding.buttonSave.setOnClickListener {
            val db = DBHelper(this, null)
            val id = intent.getLongExtra("ID", -1)
            val title = titleNote.text.toString()
            val text = textNote.text.toString()

            val sdf = SimpleDateFormat("dd/M/yyyy hh:mm:ss")
            val date = sdf.format(Date())

            if (text.isNotEmpty()) {
                if (id != -1L) {
                    db.updateNote(id, title, text, date)
                } else {
                    db.addNote(title, text, date)
                }

                Toast.makeText(this, "Заметка сохранена", Toast.LENGTH_LONG).show()
                titleNote.text.clear()
                textNote.text.clear()

                val intent = Intent(this, MainActivity::class.java)
                startActivity(intent)
                finish()
            } else {
                Toast.makeText(this, "Введите текст заметки", Toast.LENGTH_LONG).show()
            }
        }
    }
}